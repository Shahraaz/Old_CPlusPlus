#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
FILE *fin, *fout;

typedef struct Node
{
    char ch;
    int freq;
    struct Node *left, *right;
} Node;

Node **Insert(char c, int freq, Node **Heap, int *Heapsize, Node *l, Node *r)
{
    Node *temp = (Node *)malloc(sizeof(Node *));
    temp->ch = c;
    temp->freq = freq;
    temp->left = l;
    temp->right = r;

    // printf("now %d\n", *Heapsize);

    *Heapsize = *Heapsize + 1;
    int now = *Heapsize;
    // printf("now %d %d %d\n", *Heapsize, now, Heap[0]->freq);
    Heap[*Heapsize] = temp;
    // printf("now %d %d %d\n", *Heapsize, now, Heap[now]->freq);
    // printf("now %d %d\n", now, Heap[now]->freq);
    while (Heap[now / 2]->freq > temp->freq || (Heap[now / 2]->freq == temp->freq && now != 0 && (Heap[now / 2]->ch < temp->ch || Heap[now]->ch != '$')))
    {
        Heap[now] = Heap[now / 2];
        now /= 2;
    }
    Heap[now] = temp;
    return Heap;
}

Node *min;
Node **Delete(Node **Heap, int *Heapsize)
{
    Node *last;
    int child, now;
    min = Heap[1];
    last = Heap[*Heapsize];
    *Heapsize = *Heapsize - 1;
    for (now = 1; now * 2 <= *Heapsize; now = child)
    {
        child = now * 2;
        if (child != *Heapsize && Heap[child + 1]->freq < Heap[child]->freq)
        {
            child++;
        }
        if (last->freq > Heap[child]->freq)
        {
            Heap[now] = Heap[child];
        }
        else
        {
            break;
        }
    }
    Heap[now] = last;
    return Heap;
}

char Code[26][100];
void print(Node *temp, char *code)
{
    if (temp->left == NULL && temp->right == NULL)
    {
        // printf("char %c code %s\n",temp->ch,code);
        strcpy(Code[temp->ch - 'a'], code);
        return;
    }
    int length = strlen(code);
    char leftcode[10], rightcode[10];
    strcpy(leftcode, code);
    strcpy(rightcode, code);
    leftcode[length] = '0';
    leftcode[length + 1] = '\0';
    rightcode[length] = '1';
    rightcode[length + 1] = '\0';
    print(temp->left, leftcode);
    print(temp->right, rightcode);
}

int isleaf(Node *temp)
{
    return ((temp->left == NULL) && (temp->right == NULL));
}

typedef struct Leaf
{
    Node *leaf;
    int level;
    int freq;
    char ch;
}Leaf;;
Leaf *leaf[1000];
int leafcnt = 0;
void dfs(Node *temp,int level)
{
    if (temp == NULL)
        return;
    if (isleaf(temp))
    {
        Leaf* l = (Leaf*)malloc(sizeof(Leaf));
        l->leaf = temp;
        l->level = level;
        l->freq = temp->freq;
        l->ch = temp->ch;
        leaf[leafcnt++] = l;
    }
    else
    {
        dfs(temp->left,level+1);
        dfs(temp->right,level+1);
    }
}
void swap(Leaf**a, Leaf **b)
{
    Leaf* temp = *a;
    *a = *b;
    *b = temp;
}

Node *correct(Node *Tree)
{
    dfs(Tree,0);
    for(int i=0;i<leafcnt;i++)
    {
        for(int j=i;j!=0 && (leaf[j-1]->freq > leaf[j]->freq || (leaf[j-1]->freq == leaf[j]->freq) && leaf[j-1]->ch > leaf[j]->ch );j--)
            swap(&leaf[j],&leaf[j-1]);
    }
    
    for(int i=0;i<leafcnt;i++)
    
    
    return Tree;
}

int main()
{
    fin = fopen("input.txt", "r");
    fout = fopen("output.txt", "w");
    if ((fin == NULL) || (fout == NULL))
    {
        printf("Unable to open files. Try again!!\n");
        return 0;
    }
    while (!feof(fin))
    {
        Node **Heap = malloc(sizeof(Node *) * 1000);
        Node *temp = (Node *)malloc(sizeof(Node *));
        temp->ch = '$';
        temp->freq = 0;
        temp->left = temp->right = NULL;
        Heap[0] = temp;
        int heapsize = 0;
        char str[1000];
        fscanf(fin, "%s\n", str);
        // printf("string is  %s\n", str);
        int length = strlen(str), i;
        int Freq[26] = {0}, flag[26] = {0};
        for (i = 0; i < length; i++)
        {
            Freq[str[i] - 'a']++;
            flag[str[i] - 'a'] = 1;
        }
        for (i = 0; i < length; i++)
        {
            if (Freq[str[i] - 'a'] && (flag[str[i] - 'a']))
            {
                flag[str[i] - 'a'] = 0;
                // printf("%c %d\n", str[i], Freq[str[i] - 'a']);
                Heap = Insert(str[i], Freq[str[i] - 'a'], Heap, &heapsize, NULL, NULL);
            }
        }
        int n = heapsize;
        for (i = 1; i < n; i++)
        {
            Delete(Heap, &heapsize);
            Node *left = min;
            Delete(Heap, &heapsize);
            Node *right = min;
            if (isleaf(left) && isleaf(right))
                if (left->freq == right->freq)
                    if (left->ch > right->ch)
                    {
                        Node *temp = left;
                        left = right;
                        right = temp;
                    }
            Node *temp = (Node *)malloc(sizeof(Node));
            Heap = Insert('$', left->freq + right->freq, Heap, &heapsize, left, right);
            // printf("Heap\n");
            // for (int i = 0; i <= heapsize; i++)
            //     printf("%c %d\n", Heap[i]->ch, Heap[i]->freq);
            // printf("\n");
        }
        Delete(Heap, &heapsize);
        char code[100];
        Node *tree = min;
        code[0] = '\0';
        print(tree, code);
        for (i = 0; i < length; i++)
            if (Freq[str[i] - 'a'])
                printf("%s ", Code[str[i] - 'a']);
        printf("\n");
        tree = correct(tree);
        code[0] = '\0';
        print(tree, code);
        for (i = 0; i < length; i++)
            if (Freq[str[i] - 'a'])
                printf("%s ", Code[str[i] - 'a']);
        printf("\n");
    }
    return 0;
}